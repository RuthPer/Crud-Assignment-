A basic app.py with some example routes, a static folder with a css
file in it, and a templates folder with some files.

